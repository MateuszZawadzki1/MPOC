[I1, map1] = imread('autumn.tif');
[I2, map2] = imread('canoe.tif');
[I3, map3] = imread('4.1.05.BMP');
[I4, map4] = imread('4.1.06.jpg');
[I5, map5] = imread('4.1.06.tiff');
[I6, map6] = imread('4.2.03.BMP');
[I7, map7] = imread('4.2.06.BMP');
[I8, map8] = imread('4.2.07.BMP');
[I9, map9] = imread('foto08.BMP');
[I10, map10] = imread('kids.tif');
[I11, map11] = imread('LENA256.BMP');
[I12, map12] = imread('lenaRGB.tiff');


imwrite(I1,'autumn.jpeg');
imwrite(I1,'autumn.tiff');
imwrite(I1,'autumn.bmp');

imwrite(I2,'canoe.jpeg');
imwrite(I2,'canoe.tiff');
imwrite(I2,'canoe.bmp');

imwrite(I3,'4.1.05.jpeg');
imwrite(I3,'4.1.05.tiff');
imwrite(I3,'4.1.05.bmp');

imwrite(I4,'4.1.06.jpeg');
imwrite(I4,'4.1.06.tiff');
imwrite(I4,'4.1.06.bmp');

imwrite(I5,'4.2.03.jpeg');
imwrite(I5,'4.2.03.tiff');
imwrite(I5,'4.2.036.bmp');


imwrite(I5,'4.2.07.jpeg');
imwrite(I5,'4.2.07.tiff');
imwrite(I5,'4.2.07.bmp');

imwrite(I6,'foto08.jpeg');
imwrite(I6,'foto08.tiff');
imwrite(I6,'foto08.bmp');

imwrite(I7,'kids.jpeg');
imwrite(I7,'kids.tiff');
imwrite(I7,'kids.bmp');

imwrite(I8,'LENA256.jpeg');
imwrite(I8,'LENA256.tiff');
imwrite(I8,'LENA256.bmp');

imwrite(I9,'lenaRGB.jpeg');
imwrite(I9,'lenaRGB.tiff');
imwrite(I9,'lenaRGB.bmp');
