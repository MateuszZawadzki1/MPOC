[I1, map1] = imread('autumn.tif');
[I2, map2] = imread('canoe.tif');
[I3, map3] = imread('4.1.05.BMP');
[I4, map4] = imread('4.1.06.jpg');
[I5, map5] = imread('4.1.06.tiff');
[I6, map6] = imread('4.2.03.BMP');
[I7, map7] = imread('4.2.06.BMP');
[I8, map8] = imread('4.2.07.BMP');
[I11, map11] = imread('foto08.BMP');
[I12, map12] = imread('kids.tif');
[I13, map13] = imread('LENA256.BMP');
[I14, map14] = imread('lenaRGB.tiff');

figure(1);
imshow(I1, map1);

figure(2);
imshow(I2, map2);

figure(3);
imshow(I3, map3);

figure(4);
imshow(I4, map4);

figure(5);
imshow(I5, map5);

figure(6);
imshow(I6, map6);

figure(7);
imshow(I7, map7);

figure(8);
imshow(I8, map8);

figure(9);
imshow(I11, map11);

figure(10);
imshow(I12, map12);

figure(11);
imshow(I13, map13);

figure(12);
imshow(I14, map14);

